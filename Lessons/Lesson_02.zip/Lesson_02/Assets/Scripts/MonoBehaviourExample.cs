﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonoBehaviourExample : MonoBehaviour
{
    private void Awake()
    {
        gameObject.SetActive(false);
        //gameObject.activeInHierarchy;
        var component = gameObject.AddComponent<CodeStyleExample>();
        var rigidBody = gameObject.GetComponent<Rigidbody>();
        if (rigidBody == null)
        {
            //error;
        }
        else
        {
            //Do something
        }
        var componentInChildren = gameObject.GetComponentsInChildren<Rigidbody>();
        var componentInParent = gameObject.GetComponentsInParent<Rigidbody>();
        gameObject.CompareTag("");
        Rigidbody rigidBodyTry;
        if (gameObject.TryGetComponent<Rigidbody>(out rigidBodyTry))
        {

        }

        //transform.rotation.eulerAngles

        //transform.localScale
        var parent = transform.parent;
    }

    private void OnEnable()
    {   
    }

    private void OnLevelWasLoaded(int level)
    {   
    }

    private void Start()
    {
        //gameObject.SetActive(true);
        //gameObject.GetComponent<StringExample>();
        gameObject.name = "MonoTest";
        //transform.parent
        //transform.hasChanged;
        transform.eulerAngles= new Vector3(90, 0, 0);
        //transform.right;
        //transform.up;
        //transform.forward;
    }

    private void FixedUpdate()
    {   
    }

    // Update is called once per frame
    private void Update()
    {
    }

    private void LateUpdate()
    {
    }

    private void OnApplicationQuit()
    {
    }

    private void OnDisable()
    {
    }

    private void OnDestroy()
    {
    }
}
