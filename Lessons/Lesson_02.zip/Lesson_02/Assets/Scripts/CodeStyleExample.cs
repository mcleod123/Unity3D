﻿using BaseLogic;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace BaseLogic
{
    public interface ISomeUsefulInterface
    {
        void SomeAction();
    }
}

public enum PlayerState
{
    Idle,
    Run,
    Walk,
    Jump
}

public class CodeStyleExample : MonoBehaviour, ISomeUsefulInterface
{
    public const int DefaultPlayerHealthPoint = 100;
    private const string SomeConstants = "Useful Constant";

    public delegate void PlayerStateDelegate(PlayerState state);

    public event PlayerStateDelegate OnPlayerStateChange;

    [SerializeField]
    private float _someUsefulFloat;

    //public int HealthPoint => _healthPoint;

    public int HealthPoint
    {
        get
        {
            return _healthPoint;
        }
    }

    public int ExperiencePoint 
    {
        get
        {
            return _experiencePoint;
        }
        set
        {
            DoSomeActionsWithExperience();
            _experiencePoint = value;
        }
    }

    public float Duration;

    protected string _dataKey;

    private int _experiencePoint;
    private int _healthPoint;
    public void SomeAction()
    {
        //
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    protected virtual void SomeProtectedActionWithParameters(string data, int id, PlayerState state)
    {
        var parsedData = data.Split(',');
    }

    private void DoSomeActionsWithExperience()
    {

    }
}
