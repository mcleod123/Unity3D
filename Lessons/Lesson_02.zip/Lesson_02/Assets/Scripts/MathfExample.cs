﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MathfExample : MonoBehaviour
{
    [SerializeField] private Transform _pointA;
    [SerializeField] private Transform _pointB;

    [SerializeField] private float _speed = 2.5f;

    [SerializeField] private float _time = 2f;

    [SerializeField] private Transform _target;

    [SerializeField] private bool _useLerp = false;
    [SerializeField] private bool _useCoinsLerp = false;

    [SerializeField] private Text _text;

    private Vector3 _direction;

    private float _timeCounter;

    private bool _strartToMove = false;
    private bool _strartCoinsLerp = false;

    private int _coinsCounter;
    private int _coinsDelta;
    private int _coinsStart;



    private void Awake()
    {
        
        float t = 0f;
        Mathf.Lerp(0, 10, t);

        var someValue = Mathf.Clamp(_time, 0.1f, 3f);
    }

    // Start is called before the first frame update
    void Start()
    {
        _target.position = _pointA.position;
        _direction = (_pointB.position - _pointA.position).normalized;
        SetCoinsText();
    }

    // Update is called once per frame
    void Update()
    {
        if (_strartCoinsLerp)
        {
            LerpCoinsCounter();
        }

        if (!_strartToMove)
        {
            return;
        }

        //if (_useLerp)
        //{
        //    MoveLerp();
        //}
        //else
        //{
        //    MoveSimple();
        //}


    }

    private void MoveSimple()
    {
        var distance = Vector3.Distance(_target.position, _pointB.position);
        if (distance <= 0.1f)
        {
            return;
        }

        _target.position += _direction * _speed;
        
    }

    private void MoveLerp()
    {
        if (_timeCounter >= _time)
        {
            return;
        }

        var normalizedTime = _timeCounter / _time;

        _target.position = Vector3.Lerp(_target.position, _pointB.position, Time.deltaTime);

        _timeCounter += Time.deltaTime;
    }

    [ContextMenu("Start Coins")]
    private void AddCoins()
    {
        _coinsDelta = UnityEngine.Random.Range(10, 99);
        _coinsStart = _coinsCounter;
        _strartCoinsLerp = true;
        _timeCounter = 0;
    }

    private void LerpCoinsCounter()
    {
        if (_timeCounter >= _time)
        {
            return;
        }
        var normalizedTime = _timeCounter / _time;
        _coinsCounter = (int) Mathf.Lerp((float)_coinsStart, (float)(_coinsDelta + _coinsStart), normalizedTime);
        _timeCounter += Time.deltaTime;
        SetCoinsText();
    }


    private void SetCoinsText()
    {
        _text.text = _coinsCounter.ToString();
    }

    [ContextMenu("Start To Move")]
    private void StartToMove()
    {
        _strartToMove = true;
    }
}
